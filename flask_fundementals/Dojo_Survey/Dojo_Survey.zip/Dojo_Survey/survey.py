from flask import Flask, render_template, request, redirect

app = Flask(__name__)

print(__name__)

@app.route('/')

def formInput():
	return render_template('survey.html')

@app.route('/data', methods = ['POST'])
def dataView():
	print('harvested data')
	name = request.form['name']
	email = request.form['email']

	return render_template('dataFromSurvey.html', name= name, email=email)

@app.route('/danger')
def showInConsole():
	print("some is doing some danger.....")
	return None

if __name__ == '__main__':
	app.run(debug = True)